from django.apps import AppConfig


class Vers1Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'vers1'
